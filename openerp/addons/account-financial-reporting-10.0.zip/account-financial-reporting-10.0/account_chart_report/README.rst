Print chart of accounts
=======================

This module adds the menu Accounting \ Charts \ Print chart of Accounts
to allow printing the selected chart of accounts.

**Remark**: This module is based on the deprecated RML engine report.

Credits
=======

Contributors
------------

* Marc Cassuto (marc.cassuto@savoirfairelinux.com)
* Mathieu Benoit (mathieu.benoit@savoirfairelinux.com)
* Guillaume Auger (guillaume.auger@savoirfairelinux.com)

Maintainer
----------

.. image:: http://odoo-community.org/logo.png
   :alt: Odoo Community Association
   :target: http://odoo-community.org

This module is maintained by the OCA.

OCA, or the Odoo Community Association, is a nonprofit organization whose mission is to support the collaborative development of Odoo features and promote its widespread use.
